import { createApp } from 'vue'
import { createStore } from 'vuex'



let store = createStore({
    state () {},
    mutations: {},
    actions: {},
    getters: {}
  });

  const app = createApp({ /* your root component */ })

  // Install the store instance as a plugin
  app.use(store)

  export default 'store'