<template>
    <div class="v-catalog">
        <h1>catalog</h1>
        <div class="v-catalog__list">
            <VCatalogItem 
            v-for="album in albums"
            :key="album.article"
            :album_data="album"
            @sendArticle="showChildArticleInConsole"
            />
        </div>

    </div>
</template>

<script>
import VCatalogItem from './v-catalog-item.vue';
export default {
    name: "v-catalog",
    components: {
        VCatalogItem
    },
    props: {},
    data() {
        return {
            "albums": [
                {
                    cover: "cover1.png",
                    project: "Faces (Re-Release)",
                    artist: "Mac Miller",
                    price: "49.99",
                    genre: "Hip-Hop",
                    released: "2021",
                    article: "T1"
                },
                {
                    cover: "cover2.png",
                    project: "GO:OD AM",
                    artist: "Mac Miller",
                    price: "26.95",
                    genre: "Hip-Hop",
                    released: "2015",
                    article: "T2"
                },
                {
                    cover: "cover3.png",
                    project: "The Devine Feminine",
                    artist: "Mac Miller",
                    price: "27.99",
                    genre: "Hip-Hop",
                    released: "2016",
                    article: "T3"
                },

                {
                    cover: "cover4.jpg",
                    project: "Swimming",
                    artist: "Mac Miller",
                    price: "29.99",
                    genre: "Hip-Hop",
                    released: "2018",
                    article: "T4"
                },
                {
                    cover: "cover5.png",
                    project: "Circles",
                    artist: "Mac Miller",
                    price: "35.00",
                    genre: "Hip-Hop",
                    released: "2020",
                    article: "T5"
                },
                {
                    cover: "cover6.jpg",
                    project: "Flower Boy",
                    artist: "Tyler, the Creator",
                    price: "24.99",
                    genre: "Hip-Hop",
                    released: "2017",
                    article: "T6"
                },
                {
                    cover: "cover7.png",
                    project: "IGOR",
                    artist: "Tyler, the Creator",
                    price: "29.99",
                    genre: "Hip-Hop",
                    released: "2019",
                    article: "T7"
                },
                {
                    cover: "cover8.png",
                    project: "CALL ME IF YOU GET LOST",
                    artist: "Tyler, the Creator",
                    price: "27.95",
                    genre: "Hip-Hop",
                    released: "2021",
                    article: "T8"
                },

                {
                    cover: "cover9.jpg",
                    project: "Nothing Great About Britain",
                    artist: "slowthai",
                    price: "35.95",
                    genre: "Hip-Hop",
                    released: "2019",
                    article: "T9"
                },
                {
                    cover: "cover10.png",
                    project: "TYRON",
                    artist: "slowthai",
                    price: "39.99",
                    genre: "Hip-Hop",
                    released: "2021",
                    article: "T10"
                }
            ]
        }

    },
    computed: {},
    methods: {
        showChildArticleInConsole(data) {
            console.log(data)
        }
    }
}
</script>

<style>
.v-catalog__list {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
}
</style>