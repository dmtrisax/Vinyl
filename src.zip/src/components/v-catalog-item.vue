<template>
    <div class="v-catalog-item">
    <img class="v-catalog-item__cover" :src=" require('../assets/covers/' + album_data.cover) " alt="cover">
    <p class="v-catalog-item__title">{{album_data.artist}} - {{album_data.project}}</p>
    <p class="v-catalog-item__sub">{{album_data.genre}}/{{album_data.released}}</p>
    <p class="v-catalog-item__price">${{album_data.price}}</p>

    <button @click='sendDataToParent'>Add to cart</button>        
    </div>
</template>

<script>




export default {
    name: "v-catalog-item",
    props: {
        album_data: {
            type: Object,
            default() {
                return {}
            }
        }
    },
    data() {
        return {}
    },
    computed: {},
    methods: {
        sendDataToParent() {
            this.$emit("sendArticle", this.album_data.article )
        }
    }
}
</script>

<style>
     .v-catalog-item {
        flex-basis: 25%;
        box-shadow: 0 0 8px 0 #e0e0e0;
        padding: 16px;
        margin-bottom: 16px;

    }

    .v-catalog-item__cover {
        max-width: 200px;
    }
</style>