<template>
    <div class="v-cart">
        <h1>cart</h1>
        <VCartItem />
    </div>
</template>

<script>
import VCartItem from "./v-cart-item.vue";
    

    export default {
    name: "v-cart",
    props: {},
    data() {
        return {};
    },
    computed: {},
    components: { VCartItem }
}
</script>