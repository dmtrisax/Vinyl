<template>
    <div class="v-main-wrapper">
        <p>{{title}}</p>
        <VCatalog />
        <VCart />
    </div>
</template>

<script>
import VCatalog from './v-catalog.vue';
import VCart from './v-cart.vue';

    export default {
        name: 'v-main-wrapper',
        components: {
    VCatalog,
    VCart
},
        props: {},
        data() {
            return {
                title: 'main wrapper'
            }
        }, 
        computed: {},
        methods: {},
        watch: {},
        mounted() {
            console.log('hello')
        }
    }
</script>

<style>
    .v-main-wrapper {
       
        max-width: 900px;
        margin: 0 auto;
    }
</style>