<template>
    <div class="v-cart-item">
        <p>cart</p>
    </div>
</template>

<script>
    
    export default {
        name: "v-cart-item",
        props: {},
        data() {
            return {}
        },
        computed: {}
    }
</script>